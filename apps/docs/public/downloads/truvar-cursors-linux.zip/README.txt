Truvar Cursors for Linux, version 1.0.0
https://design-system.truvar.ai/docs/cursors/

Install
  unzip truvar-cursors-linux.zip -d truvar-cursors && sh truvar-cursors/install.sh

  Add "gold" or "duo" at the end for Truvar Gold or Truvar Duo:  sh truvar-cursors/install.sh duo

Or by hand: copy the Truvar-Blue, Truvar-Gold and Truvar-Duo folders into ~/.local/share/icons, then choose the
cursor in your desktop settings:
  GNOME: Settings > Appearance, or GNOME Tweaks > Appearance > Cursor
  KDE Plasma: System Settings > Colors & Themes > Cursors
  Others: your desktop's appearance settings, or XCURSOR_THEME=Truvar-Blue

Log out and in again if some apps still show the old cursor.

Remove: delete ~/.local/share/icons/Truvar-Blue, Truvar-Gold and Truvar-Duo (and the links in ~/.icons).

Truvar Cursors are free to use. (c) Truvar.ai, MIT licence.
