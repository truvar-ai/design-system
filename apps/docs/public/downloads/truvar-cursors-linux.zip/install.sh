#!/bin/sh
# Installs Truvar Blue, Gold and Duo for your user, then turns on the one you name (Blue by default).
#   ./install.sh          Truvar Blue
#   ./install.sh gold     Truvar Gold
#   ./install.sh duo      Truvar Duo (both colours)
set -e
cd "$(dirname "$0")"
DEST="${XDG_DATA_HOME:-$HOME/.local/share}/icons"
mkdir -p "$DEST" "$HOME/.icons"
for t in Truvar-Blue Truvar-Gold Truvar-Duo; do
  rm -rf "$DEST/$t" && cp -a "$t" "$DEST/"
  ln -sfn "$DEST/$t" "$HOME/.icons/$t"   # some X11 apps only look in ~/.icons
done
case "${1:-blue}" in gold|Gold) THEME=Truvar-Gold ;; duo|Duo) THEME=Truvar-Duo ;; *) THEME=Truvar-Blue ;; esac
if command -v gsettings >/dev/null 2>&1; then
  gsettings set org.gnome.desktop.interface cursor-theme "$THEME" 2>/dev/null || true
fi
if command -v plasma-apply-cursortheme >/dev/null 2>&1; then
  plasma-apply-cursortheme "$THEME" || true
fi
echo "Installed. $THEME is on; if it isn't, choose it in your desktop settings (Appearance or Cursors)."
