Truvar Cursors for Windows 10 and 11, version 1.0.0
https://design-system.truvar.ai/docs/cursors/

Install
1. Open the folder of the colour you want: Truvar Blue, Truvar Gold or Truvar Duo (both colours).
2. Right-click install.inf and choose Install (on Windows 11, choose Show more options first).
   Windows asks for permission, because the files are copied to C:\Windows\Cursors.
3. Open Settings > Bluetooth & devices > Mouse > Additional mouse settings > Pointers
   (or press Windows + R, type  main.cpl ,,1  and press Enter).
4. Under Scheme, choose Truvar Blue, Truvar Gold or Truvar Duo, then press OK.

Bigger cursors: Settings > Accessibility > Mouse pointer and touch > Size.

Remove
In the same Pointers tab, choose the scheme, press Delete, then choose Windows Default and press OK.
You can also delete the folder C:\Windows\Cursors\Truvar Blue (or Truvar Gold, Truvar Duo).

Truvar Cursors are free to use. (c) Truvar.ai, MIT licence.
